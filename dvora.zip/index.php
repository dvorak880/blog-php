<?php require_once 'header.php';?>

  <main role="main">

  <!-- Main jumbotron for a primary marketing message or call to action -->
  <div class= "jumbotron">
    <div class="container">
      <h1 class="display-3 text-dark">Hello!</h1>
      <p class=text-dark>Looking for new food blogs to read? It’s always smart to read around in your niche, and even outside of it, to stay up-to-date with what’s trending, best practices, and to see how you could make your food blog stand out from the crowd.</p>
      <p><a class="btn btn-secondary" href="logIN.php" role="button">Sign in/Sign up &raquo;</a></p>
    </div>
    </div>
  

  <div class="container">
    <!-- Example row of columns -->
    <div class="row">



 
     
    </div>
<?php require_once 'footer.php' ;?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
body{background-image: url("coffe.jpg");
    background-size: cover;
   
}
    </style>
</head>
<body>
    
</body>
</html>