$('.ms').delay(2000).slideUp();
$('#summernote').summernote({
    height: 300,
});